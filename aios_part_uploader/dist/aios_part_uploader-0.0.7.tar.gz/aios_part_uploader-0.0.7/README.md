1. `python setup.py sdist`
2. `pip install twine`
3. `twine upload dist/aios_part_uploader-0.0.1.tar.gz`